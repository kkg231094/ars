package com.capgemini.ars.dto;

public class FlightInformation {

	private String flightNumber;
	private String flightAirline;
	private String departureCity;
	private String arrivalCity;
	private String departureDate;
	private String arrivalDate;
	private String departureTime;
	private String arrivalTime;
	private String firstSeat;
	private double firstSeatFare;
	private String businessSeat;
	private double businessSeatFare;
	
	public FlightInformation() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param flightNumber
	 * @param flightAirline
	 * @param departureCity
	 * @param arrivalCity
	 * @param departureDate
	 * @param arrivalDate
	 * @param departureTime
	 * @param arrivalTime
	 * @param firstSeat
	 * @param firstSeatFare
	 * @param businessSeat
	 * @param businessSeatFare
	 */
	public FlightInformation(String flightNumber, String flightAirline,
			String departureCity, String arrivalCity, String departureDate,
			String arrivalDate, String departureTime, String arrivalTime,
			String firstSeat, double firstSeatFare, String businessSeat,
			double businessSeatFare) {
		super();
		this.flightNumber = flightNumber;
		this.flightAirline = flightAirline;
		this.departureCity = departureCity;
		this.arrivalCity = arrivalCity;
		this.departureDate = departureDate;
		this.arrivalDate = arrivalDate;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
		this.firstSeat = firstSeat;
		this.firstSeatFare = firstSeatFare;
		this.businessSeat = businessSeat;
		this.businessSeatFare = businessSeatFare;
	}

	/**
	 * @return the flightNumber
	 */
	public String getFlightNumber() {
		return flightNumber;
	}

	/**
	 * @param flightNumber the flightNumber to set
	 */
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	/**
	 * @return the flightAirline
	 */
	public String getFlightAirline() {
		return flightAirline;
	}

	/**
	 * @param flightAirline the flightAirline to set
	 */
	public void setFlightAirline(String flightAirline) {
		this.flightAirline = flightAirline;
	}

	/**
	 * @return the departureCity
	 */
	public String getDepartureCity() {
		return departureCity;
	}

	/**
	 * @param departureCity the departureCity to set
	 */
	public void setDepartureCity(String departureCity) {
		this.departureCity = departureCity;
	}

	/**
	 * @return the arrivalCity
	 */
	public String getArrivalCity() {
		return arrivalCity;
	}

	/**
	 * @param arrivalCity the arrivalCity to set
	 */
	public void setArrivalCity(String arrivalCity) {
		this.arrivalCity = arrivalCity;
	}

	/**
	 * @return the departureDate
	 */
	public String getDepartureDate() {
		return departureDate;
	}

	/**
	 * @param departureDate the departureDate to set
	 */
	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}

	/**
	 * @return the arrivalDate
	 */
	public String getArrivalDate() {
		return arrivalDate;
	}

	/**
	 * @param arrivalDate the arrivalDate to set
	 */
	public void setArrivalDate(String arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	/**
	 * @return the departureTime
	 */
	public String getDepartureTime() {
		return departureTime;
	}

	/**
	 * @param departureTime the departureTime to set
	 */
	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}

	/**
	 * @return the arrivalTime
	 */
	public String getArrivalTime() {
		return arrivalTime;
	}

	/**
	 * @param arrivalTime the arrivalTime to set
	 */
	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	/**
	 * @return the firstSeat
	 */
	public String getFirstSeat() {
		return firstSeat;
	}

	/**
	 * @param firstSeat the firstSeat to set
	 */
	public void setFirstSeat(String firstSeat) {
		this.firstSeat = firstSeat;
	}

	/**
	 * @return the firstSeatFare
	 */
	public double getFirstSeatFare() {
		return firstSeatFare;
	}

	/**
	 * @param firstSeatFare the firstSeatFare to set
	 */
	public void setFirstSeatFare(double firstSeatFare) {
		this.firstSeatFare = firstSeatFare;
	}

	/**
	 * @return the businessSeat
	 */
	public String getBusinessSeat() {
		return businessSeat;
	}

	/**
	 * @param businessSeat the businessSeat to set
	 */
	public void setBusinessSeat(String businessSeat) {
		this.businessSeat = businessSeat;
	}

	/**
	 * @return the businessSeatFare
	 */
	public double getBusinessSeatFare() {
		return businessSeatFare;
	}

	/**
	 * @param businessSeatFare the businessSeatFare to set
	 */
	public void setBusinessSeatFare(double businessSeatFare) {
		this.businessSeatFare = businessSeatFare;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "FlightInformation [flightNumber=" + flightNumber
				+ ", flightAirline=" + flightAirline + ", departureCity="
				+ departureCity + ", arrivalCity=" + arrivalCity
				+ ", departureDate=" + departureDate + ", arrivalDate="
				+ arrivalDate + ", departureTime=" + departureTime
				+ ", arrivalTime=" + arrivalTime + ", firstSeat=" + firstSeat
				+ ", firstSeatFare=" + firstSeatFare + ", businessSeat="
				+ businessSeat + ", businessSeatFare=" + businessSeatFare + "]";
	}
	
} 
