package com.capgemini.ars.service;

import com.capgemini.ars.dao.UsersDao;
import com.capgemini.ars.dao.UsersDaoImpl;
import com.capgemini.ars.dto.Users;


public class UsersServiceImpl implements UsersService{

	private UsersDao userDao;
	public UsersServiceImpl() {
		userDao = new UsersDaoImpl();
	}
	@Override
	public boolean validateUser(Users user) {
		
		return userDao.validateUser(user);
	}

}
