package com.capgemini.ars.dao;

public interface BookingDao {
	
	public void addBooking();

}
