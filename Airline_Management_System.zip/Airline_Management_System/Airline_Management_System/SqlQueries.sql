
SQL> 
create table FlightInformation(flightno varchar2(5), airline varchar2(10),
dep_city varchar2(10), arr_city varchar2(10), dep_date date, arr_date date, dep_
time varchar2(10), arr_time varchar2(10), FirstSeats number(3), FirstSeatFare nu
mber(5), BussSeats number(3), BussSeatsFare number(7));



create table FlightInformation(flightno varchar2(5), airline varchar2(10),dep_city varchar2(10), arr_city varchar2(10), dep_date date, arr_date date, dep_time varchar2(10), arr_time varchar2(10), FirstSeats number(3), FirstSeatFare number(5), BussSeats number(3), BussSeatsFare number(7));

create table BookingInformation(Booking_id varchar2(5), cust_email varchar2(20), no_of_passengers number(2), class_type varchar2(10), total_fare number(7,2), seat_number varchar2(10), CreditCard_info varchar2(10), src_city varchar2(10), dest_city varchar2(10));



create table Users(username varchar2(20), password varchar2(20), role varchar2(10), mobile_no number(10));

SELECT * FROM flightinformation WHERE arr_city='pune'  AND dep_city='bangolre' AND dep_date='17-NOV-2016';

INSERT INTO users('user','user','user',789);