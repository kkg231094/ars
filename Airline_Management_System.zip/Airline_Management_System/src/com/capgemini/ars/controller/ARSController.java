package com.capgemini.ars.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.ars.dto.FlightInformation;
import com.capgemini.ars.dto.Passenger;
import com.capgemini.ars.dto.Users;
import com.capgemini.ars.service.FlightInformationService;
import com.capgemini.ars.service.FlightInformationServiceImpl;
import com.capgemini.ars.service.UsersService;
import com.capgemini.ars.service.UsersServiceImpl;

/**
 * Servlet implementation class ARSController
 */
@WebServlet("/ARSController")
public class ARSController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String oldFlightNumber;
	private FlightInformationService flightInfoService;
	private UsersService userService;
    public ARSController() {
       flightInfoService = new FlightInformationServiceImpl();
       userService = new UsersServiceImpl();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession usersession = request.getSession(true);
		
		if(usersession == null){
			usersession.invalidate();
			RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
			//request.setAttribute("errorMessage", "You need to login to access this page <a href = 'Login.jsp'>Click Here></a>to Login");
			rd.forward(request, response);
			return;
		}
		String choice = request.getParameter("action");
		switch (choice) {
		case "add":
					String flightNumber = request.getParameter("flightNumber");
					String flightAirline = request.getParameter("flightAirline");
					String departureCity = request.getParameter("departureCity");
					String arrivalCity = request.getParameter("arrivalCity");
					String departureDate = request.getParameter("departureDate");
					String arrivalDate = request.getParameter("arrivalDate");                                                                         
					String departureTime = request.getParameter("departureTime");
					String arrivalTime = request.getParameter("arrivalTime");
					String firstSeat = request.getParameter("firstSeat");
					String firstSeatFare = request.getParameter("firstSeatFare");
					String businessSeat = request.getParameter("businessSeat");
					String businessSeatFare = request.getParameter("businessSeatFare");
					
					FlightInformation flightInfo = new FlightInformation();
					
					flightInfo.setFlightNumber(flightNumber);
					flightInfo.setFlightAirline(flightAirline);
					flightInfo.setDepartureCity(departureCity);
					flightInfo.setArrivalCity(arrivalCity);
					flightInfo.setDepartureDate(departureDate);
					flightInfo.setArrivalDate(arrivalDate);
					flightInfo.setDepartureTime(departureTime);
					flightInfo.setArrivalTime(arrivalTime);
					flightInfo.setFirstSeat(firstSeat);
					flightInfo.setFirstSeatFare(Double.parseDouble(firstSeatFare));
					flightInfo.setBusinessSeat(businessSeat);
					flightInfo.setBusinessSeatFare(Double.parseDouble(businessSeatFare));
					
					flightInfoService.addFlight(flightInfo);
					
			break;
			
		case "fetchFlightDetail":
					String flightNo = request.getParameter("flightnumber");
					oldFlightNumber = flightNo;
					FlightInformation fInfo = flightInfoService.fetchFlightDetails(flightNo);
					RequestDispatcher req = request.getRequestDispatcher("UpdateFlightEdit.jsp");
					request.setAttribute("myList", fInfo);
					req.forward(request, response);
					
			break;
			
		case "fetch": 
					List<String> myList = flightInfoService.fetchFlightNumber();
					RequestDispatcher rd = request.getRequestDispatcher("Updateflight.jsp");
					request.setAttribute("myList",myList);
					rd.forward(request, response);
		
			break;
			
		case "updateFlightDetails":
									String flightNum = request.getParameter("flightNumber");
									String flightAir = request.getParameter("flightAirline");
									String depCity = request.getParameter("departureCity");
									String arrCity = request.getParameter("arrivalCity");
									String depDate = request.getParameter("departureDate");
									String arrDate = request.getParameter("arrivalDate");                                                                         
									String depTime = request.getParameter("departureTime");
									String arrTime = request.getParameter("arrivalTime");
									String firsSeat = request.getParameter("firstSeat");
									String firsSeatFare = request.getParameter("firstSeatFare");
									String busSeat = request.getParameter("businessSeat");
									String busFare = request.getParameter("businessSeatFare");
									
									FlightInformation flightInformation = new FlightInformation();
									flightInformation.setFlightNumber(flightNum);
									flightInformation.setFlightAirline(flightAir);
									flightInformation.setDepartureCity(depCity);
									flightInformation.setArrivalCity(arrCity);
									flightInformation.setDepartureDate(depDate);
									flightInformation.setArrivalDate(arrDate);
									flightInformation.setDepartureTime(depTime);
									flightInformation.setArrivalTime(arrTime);
									flightInformation.setFirstSeat(firsSeat);
									flightInformation.setFirstSeatFare(Double.parseDouble(firsSeatFare));
									flightInformation.setBusinessSeat(busSeat);
									flightInformation.setBusinessSeatFare(Double.parseDouble(busFare));
									
									flightInfoService.updateFlightDetails(flightInformation, oldFlightNumber);
									RequestDispatcher reruest = request.getRequestDispatcher("Admin.jsp");
									reruest.forward(request, response);
			break;
			
		case "fetchSDDetails":
			List<String> destinationList= flightInfoService.getDestination();
			RequestDispatcher rd1 = request.getRequestDispatcher("ViewFlight.jsp");
			request.setAttribute("myList",destinationList);
			rd1.forward(request, response);
		
		case "ViewFlightDetails":String destinationValue = request.getParameter("destinationValue");
								 String flightDate = request.getParameter("flightDate");
								 List<FlightInformation> viewFlightList = flightInfoService.viewFlightDetails(flightDate, destinationValue);
								 RequestDispatcher rds = request.getRequestDispatcher("ViewFlightDetails.jsp");
								 request.setAttribute("viewFlightList",viewFlightList);
								 rds.forward(request, response);
			break;
			
		case "viewPassengerList":
				String viewFlightNum = request.getParameter("flightNum");
				System.out.println(viewFlightNum);
			break;
			
		case "login":
		{
			
			String email = request.getParameter("email");
			String password = request.getParameter("password");
			
			Users user = new Users();
			
			user.setUserName(email);
			user.setPassword(password);
			
			try {
				if((userService.validateUser(user) == true) && (user.getRole().equals("admin"))){
					HttpSession session = request.getSession(true);
					session.setAttribute("email",email);

					RequestDispatcher rdLogin = request.getRequestDispatcher("Admin.jsp");

					rdLogin.forward(request, response);
					break;
				}
				else{
					if((userService.validateUser(user) == true) &&  (user.getRole().equals("executive"))){
						HttpSession session = request.getSession(true);
						session.setAttribute("email",email);

						RequestDispatcher rdLogin = request.getRequestDispatcher("Executive.jsp");

						rdLogin.forward(request, response);
						break;
				}else{
					if((userService.validateUser(user) == true) && (user.getRole().equals("user"))){
						HttpSession session = request.getSession(true);
						session.setAttribute("email",email);

						RequestDispatcher rdLogin = request.getRequestDispatcher("User.jsp");

						rdLogin.forward(request, response);
						break;
					}else{
						RequestDispatcher rdLogin = request.getRequestDispatcher("Login.jsp");

						rdLogin.forward(request, response);
					}
					
				}
					
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
			break;

			
		case "addUser":
		{
			String name = request.getParameter("name");
			String password = request.getParameter("password");
			String repassword = request.getParameter("repassword");
			String email = request.getParameter("email");
			String mobileNum = request.getParameter("mobile_no");
			
			Users user = new Users();
			if(password.equals(repassword)){
				user.setUserName(email);
				user.setPassword(password);
				user.setMobileNum(Long.parseLong(mobileNum));
			}else{
				RequestDispatcher rdAddUser = request.getRequestDispatcher("SignUp.jsp");
				request.setAttribute("errorMessage", "Password is incorrect");
				rdAddUser.forward(request, response);
			}
		}
			break;
			
		case "addPassesnger":
				String numberOfPassenger = request.getParameter("numberOfPassenger");
				
				RequestDispatcher rdAdd = request.getRequestDispatcher("AddPassanger.jsp");
				request.setAttribute("numberOfPassenger",numberOfPassenger);
				rdAdd.forward(request, response);
				break;
				
		case "addPassangerDetails":
				List<Passenger> passengerList = new ArrayList<>();
				int numberOfPassengers = Integer.parseInt(request.getParameter("numberOfPassenger"));
				for(int index=1; index<=numberOfPassengers; index++)
				{
					Passenger passenger = new Passenger();
					passenger.setName(request.getParameter("passangerName"+index));
					passenger.setAge(request.getParameter("passangerAge"+index));
					passenger.setGender(request.getParameter("passangerGender"+index));
					//System.out.println(passenger);
					passengerList.add(passenger);
				}
				RequestDispatcher rdBook = request.getRequestDispatcher("ConfirmBooking.jsp");
				request.setAttribute("passengerList", passengerList);
				request.setAttribute("numberOfPassengers", numberOfPassengers);
				rdBook.forward(request, response);
				break;
		case "logout":
			HttpSession session = request.getSession(false);
				System.out.println(session);
				
				if(session != null){
					session.invalidate();
				}
				RequestDispatcher rdLogout = request.getRequestDispatcher("index.jsp");
				rdLogout.forward(request, response);
				break;

		
		}
	}

}
